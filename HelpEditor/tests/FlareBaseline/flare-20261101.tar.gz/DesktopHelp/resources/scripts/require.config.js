require.config({
    urlArgs: 't=639291661513357998'
});